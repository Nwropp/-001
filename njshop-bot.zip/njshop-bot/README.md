# NJ SHOP Discord Bot

สร้างห้องแชทส่วนตัวอัตโนมัติใน Discord เมื่อมีออเดอร์ใหม่

---

## ไฟล์ทั้งหมด

```
njshop-bot/
├── bot.js            ← ตัว Bot หลัก
├── .env              ← ใส่ Token และ Config ทั้งหมด
├── package.json      ← dependencies
└── web-snippet.html  ← โค้ดที่ต้องเพิ่มในเว็บ
```

---

## ขั้นตอนที่ 1 — ตั้งค่า Discord Developer Portal

1. ไปที่ https://discord.com/developers/applications
2. กด **New Application** → ตั้งชื่อ (เช่น NJShopBot)
3. ไปที่แถบ **Bot** → กด **Add Bot** → คัดลอก **Token** เก็บไว้
4. เปิด **Privileged Gateway Intents**: ✅ Server Members Intent
5. ไปที่ **OAuth2 → General** → คัดลอก **Client ID**
6. ไปที่ **OAuth2 → Redirects** → เพิ่ม URL เว็บคุณ (เช่น https://njshop.com)
7. ไปที่ **OAuth2 → URL Generator**:
   - Scopes: `identify`
   - Copy URL → ทดสอบ login

---

## ขั้นตอนที่ 2 — เชิญ Bot เข้า Server

ไปที่ **OAuth2 → URL Generator**:
- Scopes: `bot`, `applications.commands`
- Bot Permissions: ✅ Manage Channels, ✅ Send Messages, ✅ View Channels

คัดลอก URL → เปิด → เลือก Server discord.gg/r4EZPJ4Tt

---

## ขั้นตอนที่ 3 — หา ID ต่างๆ ใน Discord

เปิด Discord → Settings → Advanced → **เปิด Developer Mode**

| ต้องการ | วิธีหา |
|---|---|
| Server ID (GUILD_ID) | คลิกขวาที่ชื่อ Server → Copy Server ID |
| Category ID | คลิกขวาที่ Category ที่ต้องการ → Copy Channel ID |
| Admin ID | คลิกขวาที่ชื่อตัวเอง → Copy User ID |

---

## ขั้นตอนที่ 4 — ใส่ค่าใน .env

เปิดไฟล์ `.env` แล้วแก้ให้ครบ:

```
DISCORD_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
GUILD_ID=123456789012345678
CATEGORY_ID=123456789012345678
ADMIN_ID=123456789012345678
```

---

## ขั้นตอนที่ 5 — เพิ่มโค้ดในเว็บ

เปิดไฟล์ `web-snippet.html`:
1. คัดลอกส่วน **HTML** → วางในฟอร์มจองคิวก่อนปุ่ม Submit
2. ใส่ `Client ID` ใน `DISCORD_CLIENT_ID = '...'`
3. คัดลอกส่วน **JS** → วางก่อน `</script>` สุดท้าย
4. ในฟังก์ชัน `submitBooking()` เพิ่ม:
   ```js
   discordId: document.getElementById('f-discord-id')?.value || '',
   ```

---

## ขั้นตอนที่ 6 — รัน Bot

```bash
npm install
npm start
```

---

## ผลลัพธ์

```
ลูกค้ากด "ผูก Discord" บนเว็บ
       ↓ (OAuth2 ดึง ID อัตโนมัติ)
ลูกค้ากรอกฟอร์มจองคิว
       ↓
Firebase บันทึกออเดอร์ (มี discordId)
       ↓
Bot รับรู้ทันที → สร้าง Private Channel
       ↓
ลูกค้าเห็นห้อง #order-ชื่อ-xxxx ใน Discord
```
